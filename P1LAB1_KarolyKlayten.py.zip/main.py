userNum = int(input())
userNumSquared = userNum * userNum
   
print(userNumSquared)